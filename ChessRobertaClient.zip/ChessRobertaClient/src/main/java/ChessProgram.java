import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
 
import xyz.niflheim.stockfish.StockfishClient;
import xyz.niflheim.stockfish.engine.enums.Query;
import xyz.niflheim.stockfish.engine.enums.QueryType;
import xyz.niflheim.stockfish.engine.enums.Variant;
import xyz.niflheim.stockfish.exceptions.StockfishInitException;

public class ChessProgram {
	
	public static List<String> positionList = new ArrayList<String>();
	
    public static void main(String[] args) throws StockfishInitException {
    		
    	 // Initialize the Client
         Client myClient = new Client();
         
         // Initialize the Scanner (to type moves in the console)
         Scanner myInput = new Scanner(System.in);
         
         // Initialize the Stockfish-Client
         StockfishClient stockfishClient = new StockfishClient.Builder()
     	        .setInstances(1)
     	        .setVariant(Variant.BMI2)
     	        .build();
         
         // Add initial position
         positionList.add("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1");
         
         // Boolean values to stop at the end of a game
         Boolean mate = false, stalemate = false, threefoldrepetition = false, resign = false;
         
         // Ask human which color he/she wants to play
         System.out.println("Type 'white' or 'w' to play with the white pieces and 'black' or 'b' to play with the black pieces!");
         String color = myInput.nextLine();
         while(!color.equals("white") && !color.equals("w") && !color.equals("b") && !color.equals("black"))
         {
      	   System.out.println("False input. Type 'white', 'w', 'black' or 'b' to choose your color!");
      	   color = myInput.nextLine();
         }
         
         // Start the client
         myClient.run();
         myClient.setRecievedString(null);
         
         boolean progRunning = true;
         boolean rec;
         
         // Run the Client till the game is over
         while(progRunning) {
        	 // ask who�s move (either move is calculated with stockfish or entered into the console by humans)
        	 if(positionList.get(positionList.size() - 1).split(" ")[1].equals(color.substring(0, 1)))
  		   	 {
        		 // Send the Move to the Server
        		 System.out.println("Type your move!:");
        		 myClient.setSendString(myInput.nextLine());
  		   	 }
  		   	 else
  		   	 {
  		   		 // Get the Best move in this particular position
  		   		 Query query = new Query.Builder(QueryType.Best_Move)
  		    	        .setFen(positionList.get(positionList.size() - 1))
  		    	        .build();
  			   
  		   		 stockfishClient.submit(query, result -> {
  		   			 // Rewrite input if castling (Notation of Stockfish and chesspresso are different regarding castling)
  		   			 if((result.equals("e1g1") && positionList.get(positionList.size() - 1).split(" ")[2].contains("K")) || (result.equals("e8g8") && positionList.get(positionList.size() - 1).split(" ")[2].contains("k")))
  		   			 {
  		   				 result = "0-0";
  		   			 }
  		   			 else if((result.equals("e1c1") && positionList.get(positionList.size() - 1).split(" ")[2].contains("Q")) || (result.equals("e8c8") && positionList.get(positionList.size() - 1).split(" ")[2].contains("q")))
  		   			 {
  		   				 result = "0-0-0";
  		   			 }
  				   
  		   			 // Send the Move to the Server
  		   			 System.out.println("Engine's move: " + result);
  		   			 myClient.setSendString(result); 
  		   		 });
  		   	 }
        	 
        	 // Receive the answer from the Server -> Case distinction
        	 //            - if the input was an illegal move, you have to type moves in the console till there is a valid one
        	 //            - if the game is over, break out of the while-loop and save how the game ended (mate, stalemate, threefold repetition, resignation)
        	 //            - if the input was legal and the game is not over, the game goes on
        	 rec = false;
        	 while (!rec) {
        		 try {
        			 Thread.sleep(10);
        		 } catch (InterruptedException e) {
        			 e.printStackTrace();
        		 }
        		 
        		 if(myClient.hasRecievedString()) 
        		 {
        			 String recievedString = myClient.getRecievedString();
        			 
    	      		 if(recievedString.equals("illegalMove"))
    	      		 {
    	      			 System.out.println("The Move was illegal, type a valid move!:");
          			   
              		     // Send the Move to the Server again
              		     myClient.setSendString(myInput.nextLine());
    	      		 }
    	      		 else if(recievedString.equals("Mate"))
    	      		 {
    	      			 mate = true;
    	      			 rec = true;
          			     progRunning = false;
    	      		 }
    	      		 else if(recievedString.equals("StaleMate"))
	   	      		 {
	   	      			 stalemate = true;
	   	      			 rec = true;
	         			 progRunning = false;
	   	      		 }
    	      		 else if(recievedString.equals("ThreefoldRepetition"))
	   	      		 {
	   	      			 threefoldrepetition = true;
	   	      			 rec = true;
	         			 progRunning = false;
	   	      		 }
    	      		 else if(recievedString.equals("resign"))
	   	      		 {
    	      			 resign = true;
	   	      			 rec = true;
	         			 progRunning = false;
	   	      		 }
    	      		 else
          		   	 {
              		     positionList.add(recievedString);
              		     rec = true;
          		   	 }
        		 }
        	 }
 
        	 try {
        		 Thread.sleep(60);
        	 } catch (InterruptedException e) {
        		 e.printStackTrace();
        	 }
         }
         
         // Close the console entry
         myInput.close();
         
         // State the winner if possible, otherwise state why it�s a draw
         if(mate)
         {
        	 if(positionList.get(positionList.size() - 1).split(" ")[1].equals("w"))
             {
                 System.out.println("The game is over! White wins because of Checkmate!");
             }
             else if(positionList.get(positionList.size() - 1).split(" ")[1].equals("b"))
             {
                 System.out.println("The game is over! Black wins because of Checkmate!");
             }
         }
         else if(stalemate)
         {
        	 System.out.println("The game ends in a draw, because of stalemate!");
         }
         else if(threefoldrepetition)
         {
        	 System.out.println("The game ends in a draw, because of threefold repetition!");
         }
         else if(resign && color.substring(0, 1).equals("w"))
         {
        	 System.out.println("Black wins, because of resignation by white!");
         }
         else if(resign && color.substring(0, 1).equals("b"))
         {
        	 System.out.println("White wins, because of resignation by black!");
         }
    }
}