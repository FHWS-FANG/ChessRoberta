import java.io.*;
 
import java.net.*;
import java.util.Scanner;
 
public class Client {
 
       private String hostname = "192.168.70.12";
       private int port = 30001;
 
       private InetSocketAddress address;
 
       private void createAddress() {
             address = new InetSocketAddress(hostname, port);
       }
 
       public String recievedString = new String();
 
       public void setRecievedString(String recMsg) {
             recievedString = recMsg;
       }
       
       public String getRecievedString() {
             String temp = recievedString;
             setRecievedString(null);
             return temp;
       }
       
       public boolean hasRecievedString() {
             if (recievedString != null) {
                    return true;
             }
             else {
                    return false;
             }
       }
      
       private String sendString;
       
       public void setSendString(String sendMsg) {
             sendString = sendMsg;
       }
       
       public String getSendString() {
             String temp = sendString;
             return temp;
       }
       
       public boolean hasSendString() {
             if (sendString != null) {
                    return true;
             }
             else {
                    return false;
             }
       }
 
       private boolean allRunning;
       
       private void setAllRunning(boolean run) {
             allRunning = run;
       }
       
       private boolean getAllRunning() {
             return allRunning;
       }
 
       public void run() {
    	   System.out.println("Client gestartet!");
           createAddress();
           
	       // Create new Thread
	       Thread clientThread = new Thread(new Runnable() {
	    	   @Override
               public void run() {
	    		   setAllRunning(true);
	    		   try {
	    			   // Install Socket (Connection to the Server)
                       Socket socket = new Socket();
                       // connecting
                       socket.connect(address);
                       // send to server
                       OutputStream output = socket.getOutputStream();
                       // Convert String to Stream
                       PrintWriter writer = new PrintWriter(output, true);
                       Scanner scann = new Scanner(new BufferedReader(new InputStreamReader(socket.getInputStream())));
                       Scanner myInput = new Scanner(System.in);
 
                       boolean sendC;
                       boolean empfangenC;
                       while(getAllRunning()) {
                    	   sendC = false;
                           while (!sendC) {
                        	   try {
                        		   Thread.sleep(10);
                               } catch (InterruptedException e) {
                            	   e.printStackTrace();
                               }
 
                               if(hasSendString()) {
                            	   writer.println(getSendString());
                                   writer.flush();
                                   setSendString(null);
                                   sendC = true;
                               }
                           }
                                       
                           empfangenC = false;
                           while(!empfangenC) {
                        	   if(scann.hasNextLine()) {
                        		   setRecievedString(scann.nextLine());
                                   empfangenC = true;
                               }
                           }
                           
                           try {
                        	   Thread.sleep(60);
                    	   } catch (InterruptedException e) {
                    		   e.printStackTrace();
                           }
                       }
                       
                       // Close everything
                       myInput.close();
                       scann.close();                  
                       writer.close();
                       output.close();
                       socket.close();
                   } catch (Exception e) {
                	   e.printStackTrace();
                   }
    		   }
    	   });
	       
	       clientThread.setDaemon(true);
           clientThread.start();
       }
}