package application.blocks;

import chesspresso.position.Position;
import chesspresso.move.IllegalMoveException;
import chesspresso.move.Move;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.text.SimpleDateFormat;

import javax.inject.Inject;

import com.kuka.appframework.ApplicationBlock;
import com.kuka.grippertoolbox.gripper.zimmer.ZimmerR840;
import com.kuka.roboticsAPI.deviceModel.LBR;
import com.kuka.task.ITaskLogger;

public class Init extends ApplicationBlock<Init.Result>
{
	@Inject
	private LBR roberta;
	
	// To grip with Roberta
	@Inject
	ZimmerR840 ZiGripper;
	
	@Inject
	ITaskLogger logger;
	
	public enum Result
	{
		OK,
		illegalmove
	}
	
	// Function to check if the notation of the input-string is valid
	static Boolean inputIsValid (String input)
	{
		List<String> l = new ArrayList<String>(Arrays.asList("A","B","C","D","E","F","G","H","a","b","c","d","e","f","g","h"));
        List<String> z = new ArrayList<String>(Arrays.asList("1","2","3","4","5","6","7","8"));
        List<String> p = new ArrayList<String>(Arrays.asList("r","R","n","N","b","B","q","Q"));
        
		Boolean b = false;
        if(!(input.equals("0-0") || input.equals("0-0-0")))
    	{
    		Boolean b1=false, b2=false, b3=false, b4=false, b5=true;
    		if(input.length()>0) {
        		b1 = l.contains(input.substring(0,1));
    		}
    		if(input.length()>1) {
        		b2 = z.contains(input.substring(1,2));
    		}
    		if(input.length()>2) {
        		b3 = l.contains(input.substring(2,3));
    		}
    		if(input.length()>3) {
        		b4 = z.contains(input.substring(3,4));
    		}
    		if(input.length()>4) {
        		b5 = p.contains(input.substring(4,5));
    		}
    		if(b1 && b2 && b3 && b4 && b5) {
    			b = true;
    		}
    	}
        else if (input.equals("0-0") || input.equals("0-0-0"))
        {
        	b = true;
        }
        
        if(input.equals("resign"))
        {
        	b = true;
        }
        
        return b;
	}
	
	// Function, which assigns the input-string to a move (depends on castling or not)
	static short[] getMove (String input)
	{
		short move;
        short val = 0;
        
        // Case distinction: Check if input is castling or not (different move-functions)
        if(input.equals("0-0")) {
        	move = Move.getShortCastle(0);
        }
        else if(input.equals("0-0-0")) {
        	move = Move.getLongCastle(0);
        }
        else {
	        // Translate the input to a move
	        // construct integer, which describes the starting point of the move
	        char[] f = input.substring(0, 2).toCharArray();
	        int f_1;
	        if (((int)f[0]) >= 97 && ((int)f[0]) <= 104) {
	            f_1 = ((int)f[0])-97;
	        }
	        else {
	        	f_1 = ((int)f[0])-65;
	        }
	        int f_2 = ((int)f[1]) - 49;
	        int from = 8 * f_2 + f_1;
	        
	        // construct integer, which describes the ending point of the move
	        char[] t = input.substring(2, 4).toCharArray();
	        int t_1;
	        if (((int)t[0]) >= 97 && ((int)t[0]) <= 104) {
	            t_1 = ((int)t[0])-97;
	        }
	        else {
	        	t_1 = ((int)t[0])-65;
	        }
	        int t_2 = ((int)t[1]) - 49;
	        int to = 8 * t_2 + t_1;
	        
	        // construct boolean, which describes whether it�s a capture
	        Boolean capturing = false;
	        if(position.getStone(to) != 0)
	        {
	        	capturing = true;
	        }
	        val = (short) (capturing? 1 : 0);
	        
	        // Initialize Move (Case distinction, if a pawn is promoted or not)
	        int promotion = 0;	
	        if(input.substring(4).contains("r") || input.substring(4).contains("R")) {
	        	promotion = 1;
	        }
	        if(input.substring(4).contains("n") || input.substring(4).contains("N")) {
	        	promotion = 2;
	        }
	        if(input.substring(4).contains("b") || input.substring(4).contains("B")) {
	        	promotion = 3;
	        }
	        if(input.substring(4).contains("q") || input.substring(4).contains("Q")) {
	        	promotion = 4;
	        }
	        
	        // Check if we have an en passant move (other move-function)
	        if(position.toString().split(" ")[3].equals(input.substring(2, 4)) && (position.getStone(from) == 5 || position.getStone(from) == -5)) {
	        	move = Move.getEPMove(from, to);
	        }
	        else
	        {
		        move = Move.getPawnMove(from, to, capturing, promotion);
	        }
        }
        
        short[] move_bool = {move, val};
        
        return move_bool;
	}
	
	// Function, which executes the move. Also checking if it is valid, if so store the move in the movelog, if not undo the move
	static Boolean executeMove (short move) throws IllegalMoveException
	{
		// Get all the valid moves in this position to check if the new move is one of the valid ones
        String allMoves[] = position.getMovesAsString(position.getAllMoves(), true).replace("{","").replace("}", "").split(",");
        
        // Do the move and update the position
	    position.doMove(move);
	    
        // Save the previously done move to compare it with the valid moves
        String lastMove = position.getLastMove().toString();
        
        // Check if the move was valid
        int counter = 0;
        Boolean isValid = false;
        for(int i=0; i<allMoves.length; i++)
        {
        	if(lastMove.equals(allMoves[i]))
        	{
        		counter += 1;
        	}
        }
        if (counter != 0)
        {
        	isValid = true;
        }
        
        // If the move is not valid undo the move, if it is valid save the move in the moveLog
        if(isValid)
        {
            String[] p = position.toString().split(" ");
            String positionString = p[0] + " " + p[1] + " " + p[2] + " " + p[3];
            positionLog.add(positionString);
            positionList.add(position);
            return true;
        }
        else 
        {
        	position.undoMove();
        	moveLog.remove(moveLog.size() - 1);
        	moveLog.remove(moveLog.size() - 1);
        	return false;
        }
	}
	
	// Checking if we have a threefold repetition in the game
	static Boolean isThreefoldRepetition(List<String> positionLog)
	{
		Boolean isThreefoldRepetition = false;
		int counter1 = 0;
        for(int i = 0; i < positionLog.size(); i++)
        {
        	int counter2 = 0;
        	for(int j = 0; j < positionLog.size(); j++)
        	{
        		
        		if((positionLog.get(i).equals(positionLog.get(j))) && (i != j))
        		{
        			counter2 += 1;
        		}
        	}
        	if (counter2 >= 2)
        	{
        		counter1 += 1;
        	}
        }
        if(counter1 > 0)
        {
        	isThreefoldRepetition = true;
        }
        
        return isThreefoldRepetition;
	}
	
	// The position of the Chessboard
	public static Position position;
	
	// The recording of the positions
	public static List<Position> positionList = new ArrayList<Position>();
	
	// The recording of the positions as Strings
    public static List<String> positionLog = new ArrayList<String>();

    // The recording of the moves
    public static List<String> moveLog = new ArrayList<String>();
    
    // Variable which is true if the game is over (e.g. mate, stalemate, threefold-repetition)
    public static Boolean gameOver = false;
    
    // Boolean to save if a move was illegal
    public static Boolean im = false;
    
    // Boolean to save if the player resigned
    public static Boolean resign = false;
    
    // To save the input of each turn
    private String input = null;
    
    // To save the timestamps for each turn
    String timestamp = new SimpleDateFormat("HH:mm:ss.SSS").format(new java.util.Date(System.currentTimeMillis()));
    
    // Initializing the Server
    RobertaServer myServer = new RobertaServer();
    
    @Override
	public Result run() throws Exception
	{
    	// Case distinction if it�s the first move in the game, otherwise just take the last position
        if(positionList.size() == 0)
        {
        	// Attach gripper to Roberta and open it
    	    ZiGripper.attachTo(roberta.getFlange());  
    	    ZiGripper.initialize(); 
    	    ZiGripper.gripAsync(ZimmerR840.createAbsoluteMode(21));
    	    Thread.sleep(1000);
    	    
    	    // Create initial position
        	position = Position.createInitialPosition();
        	positionLog.add(position.toString().substring(0, position.toString().length() - 4));
        	positionList.add(position);
        	
        	// Add the first timestamp, when the game started
            moveLog.add(timestamp);
        }
        else
        {
        	position = positionList.get(positionList.size() - 1);
        	
        }
        
        // Send the current position to the Client
        if(!im)
        {
            myServer.setSendString(positionList.get(positionList.size() - 1).toString());
        }
        
        // Start the Server if necessary
        if(!myServer.hasStarted)
        {
            myServer.start();

            myServer.setSendString(null);
            myServer.setRecievedString(null);
        }
        
        // Recieve the input of the next turn
        Boolean rec = false;
        while (!rec) {
            try 
            {
            	Thread.sleep(10);
            } 
            catch (InterruptedException e) {
                e.printStackTrace();
            }
            if(myServer.hasRecievedString()) {
                input = myServer.getRecievedString();
                rec = true;
            }
        } 
        
        //check if the notation of the input-string is valid. If not ask for a new input (otherwise see else-block below)
        Boolean inputIsValid = inputIsValid(input);
        if(!inputIsValid)
        {
        	im = true;
            myServer.setSendString("illegalMove");
        	return Result.illegalmove;
        }
        else if(inputIsValid && !input.equals("resign"))
        {
        	// Translate the input to a move
	        short move[] = getMove(input);
	        
	        // Add an "x" to the input if there is a capture
	        if(move[1] != 0)
	        {
	        	if(input.length() == 4)
	        	{
		        	input = input + "x";
	        	}
	        	else if(input.length() == 5)
	        	{
	        		input = input.substring(0,4) + "x" + input.substring(4,5);
	        	}
	        }
	        
	        // Save input and the current timestamp in the moveLog
	        moveLog.add(input);
	        moveLog.add(timestamp);
	        
	        Boolean valid = false;
	        // Execute move and check if it is valid, also catch some further exceptions (e.g. there is no piece on the square)
	        try {
	        	valid = executeMove(move[0]);
	        	im = false;
	        }
	        catch(RuntimeException e) {
	        	moveLog.remove(moveLog.size() - 1);
	        	moveLog.remove(moveLog.size() - 1);
	        	
	        	im = true;
	            myServer.setSendString("illegalMove"); 
	        	return Result.illegalmove;
	        }
	        
	        // Check if the move is illegal regarding the rules of chess. If it is, ask for a new input
	        if(!valid)
	        {
	        	im = true;
	            myServer.setSendString("illegalMove");
	        	return Result.illegalmove;
	        }
	        
	        // Check if there is a mate, stalemate or 3-fold-repetition in this position
	        if(position.isMate())
	        {
	        	myServer.setSendString("Mate");
	        	gameOver = true;
	        }
	        else if(position.isStaleMate())
	        {
	        	myServer.setSendString("StaleMate");
	        	gameOver = true;
	        }
	        else if(isThreefoldRepetition(positionLog))
	        {
	        	myServer.setSendString("ThreefoldRepetition");
	        	gameOver = true;
	        }
	        
	        resign = false;
		    return Result.OK;
        }
        else if(inputIsValid && input.equals("resign"))
        {
        	myServer.setSendString("resign");
        	gameOver = true;
        	resign = true;
        	return Result.OK;
        }
        return Result.OK;
	} 
}