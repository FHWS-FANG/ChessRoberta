package application.blocks;
 
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
 
public class RobertaServer {
	
	private int port = 30001;
 
    private boolean running;
    private void setRunning (boolean isRunning) {
    	running = isRunning;
    }
    private boolean getRunning() {
    	return running;
    }
    
    public boolean hasStarted = false;
                  
    private String recievedString;
    public void setRecievedString(String recStr) {
    	recievedString = recStr;
    }
    
    public String getRecievedString() {
    	String temp = recievedString;
        setRecievedString(null);
        return temp;
    }
    
    public boolean hasRecievedString() {
    	if (recievedString != null) {
    		return true;
		}
        else {
        	return false;
        }
    }
 
    private String sendString;
    public String getSendString() {
    	return sendString;
    }
    
    public void setSendString(String sendStr) {
    	sendString = sendStr;
    }
    private boolean hasSendString() {
    	if (sendString != null) {
    		return true;
		}
        else {
        	return false;
        }
    }
 
    public void stop() {
    	setRunning(false);
    	try {
    		Thread.sleep(100);
		} catch (InterruptedException e) {
			e.printStackTrace();
        }
        serverThread.interrupt();
        serverThread = null;
    }
               
    private Thread serverThread;
    
    public void start() {
    	System.out.println("Hier ist der Server!");
    	hasStarted = true;
    	
    	// Create new Thread
    	serverThread = new Thread(new Runnable() {
    		@Override
    		public void run() {
    			setRunning(true);
    			try {
    				// Make a Connection
    				ServerSocket serverSocket = new ServerSocket(port);
    				
    				// connecting
    				Socket socket = serverSocket.accept();
    				
    				// Create Scanner for input and PrintWriter for output
    				Scanner scann = new Scanner(new BufferedReader (new InputStreamReader(socket.getInputStream())));
                    PrintWriter pw = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
 
                    boolean empfangenS;
                    boolean sendenS;
                    
                    // Repeat input and output
                    while(getRunning()) {
                    	// Receive, until something is there
                    	empfangenS = false;
                    	while(!empfangenS) {
                    		if(scann.hasNextLine()) {
                    			setRecievedString(scann.nextLine());
                    			empfangenS = true;
                    			if(!getRunning()) {
                    				empfangenS = true;
                                }
                            }
                                                                                                             
                    	}
                    	
                    	// Send, until something has been sent
                    	sendenS = false;
                    	while(!sendenS) {
                    		try {
                    			Thread.sleep(10);
                			} catch (InterruptedException e) {
                				e.printStackTrace();
            				}
                    		if(hasSendString()) {
                    			pw.println(getSendString());
                    			pw.flush();
                    			setSendString(null);
                    			sendenS = true;
                    		}
                    		if(!getRunning()) {
                    			sendenS = true;
                			}
                        }
                	}
                    
                    // if something was received, close everything (will never be executed)
                    scann.close();
                    pw.close();
                    
                    socket.close();
                    serverSocket.close();
                    
                } catch (Exception e) {
                	e.printStackTrace();
            	}
			}
		});
    	
    	// Start Thread as daemon
    	serverThread.setDaemon(true);
    	serverThread.start();
	}
}