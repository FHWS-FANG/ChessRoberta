package application.blocks;

import com.kuka.appframework.ApplicationBlock;
import com.kuka.roboticsAPI.applicationModel.IApplicationData;
import com.kuka.task.ITaskLogger;

import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;

public class Init2 extends ApplicationBlock<Init2.Result>
{
	public enum Result
	{
		OK
	}
	
	// Make a console output via the Smartpad of Roberta (logger.info(String s))
	@Inject
	ITaskLogger logger;
	
	@Inject
	private IApplicationData iApp;
	
	Init vInit = new Init();
	
	// Create a list of moves, where the coordinates are saved in the way Roberta should work them off
	public static List<double[]> moveList = new ArrayList<double[]>();
	
	// Create a list that stores for each move whether Roberta should grip, release or do neither
	public static List<Boolean[]> gripList = new ArrayList<Boolean[]>();
	
	@Override
	public Result run() throws Exception
	{	
		moveList.clear();
		gripList.clear();
		
		List<String> positionLog = vInit.positionLog;
		List<String> moveLog = vInit.moveLog;
		
		// coordinates of field a1, h8 and StartPoint
		double a1x = iApp.getFrame("/Chessboard/a1").getX();
		double a1y = iApp.getFrame("/Chessboard/a1").getY();
		double z = iApp.getFrame("/Chessboard/a1").getZ();
		double h8x = iApp.getFrame("/Chessboard/h8").getX();
		double h8y = iApp.getFrame("/Chessboard/h8").getY();
        double[] sK = {iApp.getFrame("/StartPos").getX(), iApp.getFrame("/StartPos").getY(), iApp.getFrame("/StartPos").getZ()};
		
        Boolean[] grip = {true, false};
        Boolean[] release = {false, true};
        Boolean[] none = {false, false};
        
        // Calculate h1
        double h1x, h1y;
        double v1x = h8x - a1x;
        double v1y = h8y - a1y;
        double u1x = (1/Math.sqrt(2))*v1x + (1/Math.sqrt(2))*v1y;
        double u1y = -(1/Math.sqrt(2))*v1x + (1/Math.sqrt(2))*v1y;
        double u2x = -(1/Math.sqrt(2))*v1x + (1/Math.sqrt(2))*v1y;
        double u2y = -(1/Math.sqrt(2))*v1x - (1/Math.sqrt(2))*v1y;
        
        if(u1x == 0) {
        	h1x = a1x;
        	h1y = h8y;
        }
        else if(u1y == 0) {
        	h1x = h8x;
        	h1y = a1y;
        }
        else {
        	h1x = (h8y-a1y+(a1x*u1y/u1x)-(h8x*u2y/u2x))/((u1y/u1x)-(u2y/u2x));
            h1y = (h1x*u2y/u2x)+h8y-(h8x*u2y/u2x);
        }
        
        // Case distinction 
        //     - castling kingside  for white (e1->g1, h1->f1)
        //     - castling kingside  for black (e8->g8, h8->f8)
        //     - castling queenside for white (e1->c1, a1->d1)
        //     - castling queenside for black (e8->c8, a8->d8)
        //     - all other moves
        if(moveLog.get(moveLog.size() - 2).equals("0-0") && positionLog.get(positionLog.size() - 1).split(" ")[1].equals("b"))
        {
            double[] e1K = new double[3];
            double[] e1K10 = new double[3];
            double[] g1K = new double[3];
            double[] g1K10 = new double[3];
            double[] h1K = new double[3];
            double[] h1K10 = new double[3];
            double[] f1K = new double[3];
            double[] f1K10 = new double[3];
            
        	// Calculate Coordinates of e1
        	e1K[0] = a1x + (4.0/7)*(h1x-a1x);
            e1K[1] = a1y + (4.0/7)*(h1y-a1y);
            e1K[2] = z;
            
            // Create e1K10, which is 10cm above e1
            e1K10[0] = e1K[0];
            e1K10[1] = e1K[1];
            e1K10[2] = z + 100;
            
            // Calculate Coordinates of g1
        	g1K[0] = a1x + (6.0/7)*(h1x-a1x);
            g1K[1] = a1y + (6.0/7)*(h1y-a1y);
            g1K[2] = z;
            
            // Create g1K10, which is 10cm above g1
            g1K10[0] = g1K[0];
            g1K10[1] = g1K[1];
            g1K10[2] = z + 100;
            
            // Refer Coordinates of h1 and h1K10
            h1K[0] = h1x;
            h1K[1] = h1y;
            h1K[2] = z;
            h1K10[0] = h1x;
            h1K10[1] = h1y;
            h1K10[2] = z + 100;
            
            // Calculate Coordinates of f1
        	f1K[0] = a1x + (5.0/7)*(h1x-a1x);
            f1K[1] = a1y + (5.0/7)*(h1y-a1y);
            f1K[2] = z;
            
            // Create g1K10, which is 10cm above g1
            f1K10[0] = f1K[0];
            f1K10[1] = f1K[1];
            f1K10[2] = z + 100;
            
            moveList.add(sK);
        	gripList.add(none);
        	moveList.add(e1K10);
        	gripList.add(none);
        	moveList.add(e1K);
        	gripList.add(grip);
        	moveList.add(e1K10);
        	gripList.add(none);
            moveList.add(g1K10);
            gripList.add(none);
            moveList.add(g1K);
            gripList.add(release);
            moveList.add(g1K10);
            gripList.add(none);
            moveList.add(h1K10);
        	gripList.add(none);
        	moveList.add(h1K);
        	gripList.add(grip);
        	moveList.add(h1K10);
        	gripList.add(none);
            moveList.add(f1K10);
            gripList.add(none);
            moveList.add(f1K);
            gripList.add(release);
            moveList.add(f1K10);
            gripList.add(none);
        	moveList.add(sK);
        	gripList.add(none);
        }
        else if(moveLog.get(moveLog.size() - 2).equals("0-0") && positionLog.get(positionLog.size() - 1).split(" ")[1].equals("w"))
        {
        	double[] e8K = new double[3];
            double[] e8K10 = new double[3];
            double[] g8K = new double[3];
            double[] g8K10 = new double[3];
            double[] h8K = new double[3];
            double[] h8K10 = new double[3];
            double[] f8K = new double[3];
            double[] f8K10 = new double[3];
            
        	// Calculate Coordinates of e8
        	e8K[0] = a1x + (4.0/7)*(h1x-a1x) - (h1y-a1y);
            e8K[1] = a1y + (4.0/7)*(h1y-a1y) + (h1x-a1x);
            e8K[2] = z;
            
            // Create e8K10, which is 10cm above e8
            e8K10[0] = e8K[0];
            e8K10[1] = e8K[1];
            e8K10[2] = z + 100;
            
            // Calculate Coordinates of g8
            g8K[0] = a1x + (6.0/7)*(h1x-a1x) - (h1y-a1y);
            g8K[1] = a1y + (6.0/7)*(h1y-a1y) + (h1x-a1x);
            g8K[2] = z;
            
            // Create g8K10, which is 10cm above g8
            g8K10[0] = g8K[0];
            g8K10[1] = g8K[1];
            g8K10[2] = z + 100;
            
            // Refer Coordinates of h8 and h8K10
            h8K[0] = h8x;
            h8K[1] = h8y;
            h8K[2] = z;
            h8K10[0] = h8x;
            h8K10[1] = h8y;
            h8K10[2] = z + 100;
            
            // Calculate Coordinates of f8
            f8K[0] = a1x + (5.0/7)*(h1x-a1x) - (h1y-a1y);
            f8K[1] = a1y + (5.0/7)*(h1y-a1y) + (h1x-a1x);
            f8K[2] = z;
            
            // Create f8K10, which is 10cm above f8
            f8K10[0] = f8K[0];
            f8K10[1] = f8K[1];
            f8K10[2] = z + 100;
            
            moveList.add(sK);
        	gripList.add(none);
        	moveList.add(e8K10);
        	gripList.add(none);
        	moveList.add(e8K);
        	gripList.add(grip);
        	moveList.add(e8K10);
        	gripList.add(none);
            moveList.add(g8K10);
            gripList.add(none);
            moveList.add(g8K);
            gripList.add(release);
            moveList.add(g8K10);
            gripList.add(none);
            moveList.add(h8K10);
        	gripList.add(none);
        	moveList.add(h8K);
        	gripList.add(grip);
        	moveList.add(h8K10);
        	gripList.add(none);
            moveList.add(f8K10);
            gripList.add(none);
            moveList.add(f8K);
            gripList.add(release);
            moveList.add(f8K10);
            gripList.add(none);
        	moveList.add(sK);
        	gripList.add(none);
        }
        else if(moveLog.get(moveLog.size() - 2).equals("0-0-0") && positionLog.get(positionLog.size() - 1).split(" ")[1].equals("b"))
        {
        	double[] e1K = new double[3];
            double[] e1K10 = new double[3];
            double[] c1K = new double[3];
            double[] c1K10 = new double[3];
            double[] a1K = new double[3];
            double[] a1K10 = new double[3];
            double[] d1K = new double[3];
            double[] d1K10 = new double[3];
            
        	// Calculate Coordinates of e1
        	e1K[0] = a1x + (4.0/7)*(h1x-a1x);
            e1K[1] = a1y + (4.0/7)*(h1y-a1y);
            e1K[2] = z;
            
            // Create e1K10, which is 10cm above e1
            e1K10[0] = e1K[0];
            e1K10[1] = e1K[1];
            e1K10[2] = z + 100;
            
            // Calculate Coordinates of c1
        	c1K[0] = a1x + (2.0/7)*(h1x-a1x);
            c1K[1] = a1y + (2.0/7)*(h1y-a1y);
            c1K[2] = z;
            
            // Create c1K10, which is 10cm above c1
            c1K10[0] = c1K[0];
            c1K10[1] = c1K[1];
            c1K10[2] = z + 100;
            
            // Refer Coordinates of a1 and a1K10
            a1K[0] = a1x;
            a1K[1] = a1y;
            a1K[2] = z;
            a1K10[0] = a1x;
            a1K10[1] = a1y;
            a1K10[2] = z + 100;
            
            // Calculate Coordinates of d1
        	d1K[0] = a1x + (3.0/7)*(h1x-a1x);
            d1K[1] = a1y + (3.0/7)*(h1y-a1y);
            d1K[2] = z;
            
            // Create d1K10, which is 10cm above d1
            d1K10[0] = d1K[0];
            d1K10[1] = d1K[1];
            d1K10[2] = z + 100;
            
            moveList.add(sK);
        	gripList.add(none);
        	moveList.add(e1K10);
        	gripList.add(none);
        	moveList.add(e1K);
        	gripList.add(grip);
        	moveList.add(e1K10);
        	gripList.add(none);
            moveList.add(c1K10);
            gripList.add(none);
            moveList.add(c1K);
            gripList.add(release);
            moveList.add(c1K10);
            gripList.add(none);
            moveList.add(a1K10);
        	gripList.add(none);
        	moveList.add(a1K);
        	gripList.add(grip);
        	moveList.add(a1K10);
        	gripList.add(none);
            moveList.add(d1K10);
            gripList.add(none);
            moveList.add(d1K);
            gripList.add(release);
            moveList.add(d1K10);
            gripList.add(none);
        	moveList.add(sK);
        	gripList.add(none);
        }
        else if(moveLog.get(moveLog.size() - 2).equals("0-0-0") && positionLog.get(positionLog.size() - 1).split(" ")[1].equals("w"))
        {
        	double[] e8K = new double[3];
            double[] e8K10 = new double[3];
            double[] c8K = new double[3];
            double[] c8K10 = new double[3];
            double[] a8K = new double[3];
            double[] a8K10 = new double[3];
            double[] d8K = new double[3];
            double[] d8K10 = new double[3];
            
        	// Calculate Coordinates of e8
        	e8K[0] = a1x + (4.0/7)*(h1x-a1x) - (h1y-a1y);
            e8K[1] = a1y + (4.0/7)*(h1y-a1y) + (h1x-a1x);
            e8K[2] = z;
            
            // Create e8K10, which is 10cm above e8
            e8K10[0] = e8K[0];
            e8K10[1] = e8K[1];
            e8K10[2] = z + 100;
            
            // Calculate Coordinates of c8
            c8K[0] = a1x + (2.0/7)*(h1x-a1x) - (h1y-a1y);
            c8K[1] = a1y + (2.0/7)*(h1y-a1y) + (h1x-a1x);
            c8K[2] = z;
            
            // Create c8K10, which is 10cm above c8
            c8K10[0] = c8K[0];
            c8K10[1] = c8K[1];
            c8K10[2] = z + 100;
            
            // Calculate Coordinates of a8
            a8K[0] = a1x - (h1y-a1y);
            a8K[1] = a1y + (h1x-a1x);
            a8K[2] = z;
            
            // Create a8K10, which is 10cm above a8
            a8K10[0] = a8K[0];
            a8K10[1] = a8K[1];
            c8K10[2] = z + 100;
            
            // Calculate Coordinates of d8
            d8K[0] = a1x + (3.0/7)*(h1x-a1x) - (h1y-a1y);
            d8K[1] = a1y + (3.0/7)*(h1y-a1y) + (h1x-a1x);
            d8K[2] = z;
            
            // Create d8K10, which is 10cm above d8
            d8K10[0] = d8K[0];
            d8K10[1] = d8K[1];
            d8K10[2] = z + 100;
            
            moveList.add(sK);
        	gripList.add(none);
        	moveList.add(e8K10);
        	gripList.add(none);
        	moveList.add(e8K);
        	gripList.add(grip);
        	moveList.add(e8K10);
        	gripList.add(none);
            moveList.add(c8K10);
            gripList.add(none);
            moveList.add(c8K);
            gripList.add(release);
            moveList.add(c8K10);
            gripList.add(none);
            moveList.add(a8K10);
        	gripList.add(none);
        	moveList.add(a8K);
        	gripList.add(grip);
        	moveList.add(a8K10);
        	gripList.add(none);
            moveList.add(d8K10);
            gripList.add(none);
            moveList.add(d8K);
            gripList.add(release);
            moveList.add(d8K10);
            gripList.add(none);
        	moveList.add(sK);
        	gripList.add(none);
        }
        else
        {
	        double[] fromK = new double[3];
	        double[] fromK10 = new double[3];
	        double[] toK = new double[3];
	        double[] toK10 = new double[3];
	        double[] outK10 = new double[3];
	        double[] p1K = new double[3];
	        double[] p1K10 = new double[3];
	        double[] p2K = new double[3];
	        double[] p2K10 = new double[3];
	        
	        // Calculate Coordinates of the field where the piece comes from
	        char[] from = moveLog.get(moveLog.size() - 2).substring(0,2).toCharArray();
	        double f_1 = (int)from[0] - 97;
	        double f_2 = (int)from[1] - 49;
	        fromK[0] = a1x + (f_1/7)*(h1x-a1x) - (f_2/7)*(h1y-a1y);
	        fromK[1] = a1y + (f_1/7)*(h1y-a1y) + (f_2/7)*(h1x-a1x);
	        fromK[2] = z;
	        
	        // Create fromK10, which is 10cm above fromK
	        fromK10[0] = fromK[0];
	        fromK10[1] = fromK[1];
	        fromK10[2] = z + 100;
	        
	        // Calculate Coordinates of the field where the piece will go
	        char[] to = moveLog.get(moveLog.size() - 2).substring(2,4).toCharArray();
	        double t_1 = (int)to[0] - 97;
	        double t_2 = (int)to[1] - 49;
	        toK[0] = a1x + (t_1/7)*(h1x-a1x) - (t_2/7)*(h1y-a1y);
	        toK[1] = a1y + (t_1/7)*(h1y-a1y) + (t_2/7)*(h1x-a1x);
	        toK[2] = z;
	        
	        // Create toK10, which is 10cm above toK
	        toK10[0] = toK[0];
	        toK10[1] = toK[1];
	        toK10[2] = z + 100;
	        
	        // Calculate Coordinates of the field where the captured pieces will go (only coordinates for 10cm above the field are necessary, because the pieces will be thrown from there) 
	        outK10[0] = a1x + (10.5/7)*(h1x-a1x) - (3.5/7)*(h1y-a1y);
	        outK10[1] = a1y + (10.5/7)*(h1y-a1y) + (3.5/7)*(h1x-a1x);
	        outK10[2] = z + 100;
	        
	        // Calculate Coordinates of the field where the white promotion-piece is
	        p1K[0] = a1x + (-2.0/7)*(h1x-a1x) - (2.0/7)*(h1y-a1y);
	        p1K[1] = a1y + (-2.0/7)*(h1y-a1y) + (2.0/7)*(h1x-a1x);
	        p1K[2] = z;
	        
	        // Create p1K10, which is 10cm above p1K
	        p1K10[0] = p1K[0];
	        p1K10[1] = p1K[1];
	        p1K10[2] = z + 100;
	        
	        // Calculate Coordinates of the field where the black promotion-piece is
	        p2K[0] = a1x + (-2.0/7)*(h1x-a1x) - (5.0/7)*(h1y-a1y);
	        p2K[1] = a1y + (-2.0/7)*(h1y-a1y) + (5.0/7)*(h1x-a1x);
	        p2K[2] = z;
	        
	        // Create p1K10, which is 10cm above p1K
	        p2K10[0] = p2K[0];
	        p2K10[1] = p2K[1];
	        p2K10[2] = z + 100;
	        
	        
	        // Case distiction (for normal move, capture, promotion (for black and white), promotion with capture (for black or white))
	        // normal move:
	        if(moveLog.get(moveLog.size() - 2).length() == 4)
	        {
	        	moveList.add(sK);
	        	gripList.add(none);
	        	moveList.add(fromK10);
	        	gripList.add(none);
	        	moveList.add(fromK);
	        	gripList.add(grip);
	        	moveList.add(fromK10);
	        	gripList.add(none);
	            moveList.add(toK10);
	            gripList.add(none);
	            moveList.add(toK);
	            gripList.add(release);
	            moveList.add(toK10);
	            gripList.add(none);
	        	moveList.add(sK);
	        	gripList.add(none);
	        }
	        // capturing:
	        else if(moveLog.get(moveLog.size() - 2).length() == 5 && moveLog.get(moveLog.size() - 2).substring(4,5).equals("x"))
	        {
	        	moveList.add(sK);
	        	gripList.add(none);
	        	moveList.add(toK10);
	        	gripList.add(none);
	        	moveList.add(toK);
	        	gripList.add(grip);
	        	moveList.add(toK10);
	        	gripList.add(none);
	        	moveList.add(outK10);
	        	gripList.add(release);
	        	moveList.add(fromK10);
	        	gripList.add(none);
	        	moveList.add(fromK);
	        	gripList.add(grip);
	        	moveList.add(fromK10);
	        	gripList.add(none);
	        	moveList.add(toK10);
	        	gripList.add(none);
	        	moveList.add(toK);
	        	gripList.add(release);
	        	moveList.add(toK10);
	        	gripList.add(none);
	        	moveList.add(sK);
	        	gripList.add(none);
	        }
	        // promotion for white without capturing:
	        else if(moveLog.get(moveLog.size() - 2).length() == 5 && !moveLog.get(moveLog.size() - 2).substring(4,5).equals("x") && positionLog.get(positionLog.size() - 1).split(" ")[1].equals("b"))
	        {
	        	moveList.add(sK);
	        	gripList.add(none);
	        	moveList.add(fromK10);
	        	gripList.add(none);
	        	moveList.add(fromK);
	        	gripList.add(grip);
	        	moveList.add(fromK10);
	        	gripList.add(none);
	        	moveList.add(outK10);
	        	gripList.add(release);
	        	moveList.add(p1K10);
	        	gripList.add(none);
	        	moveList.add(p1K);
	        	gripList.add(grip);
	        	moveList.add(p1K10);
	        	gripList.add(none);
	        	moveList.add(toK10);
	        	gripList.add(none);
	        	moveList.add(toK);
	        	gripList.add(release);
	        	moveList.add(toK10);
	        	gripList.add(none);
	        	moveList.add(sK);
	        	gripList.add(none);
	        }
	        // promotion for black without capturing:
	        else if(moveLog.get(moveLog.size() - 2).length() == 5 && !moveLog.get(moveLog.size() - 2).substring(4,5).equals("x") && positionLog.get(positionLog.size() - 1).split(" ")[1].equals("w"))
	        {
	        	moveList.add(sK);
	        	gripList.add(none);
	        	moveList.add(fromK10);
	        	gripList.add(none);
	        	moveList.add(fromK);
	        	gripList.add(grip);
	        	moveList.add(fromK10);
	        	gripList.add(none);
	        	moveList.add(outK10);
	        	gripList.add(release);
	        	moveList.add(p2K10);
	        	gripList.add(none);
	        	moveList.add(p2K);
	        	gripList.add(grip);
	        	moveList.add(p2K10);
	        	gripList.add(none);
	        	moveList.add(toK10);
	        	gripList.add(none);
	        	moveList.add(toK);
	        	gripList.add(release);
	        	moveList.add(toK10);
	        	gripList.add(none);
	        	moveList.add(sK);
	        	gripList.add(none);
	        }
	        // promotion for white with capturing:
	        else if(moveLog.get(moveLog.size() - 2).length() == 6 && positionLog.get(positionLog.size() - 1).split(" ")[1].equals("b"))
	        {
	        	moveList.add(sK);
	        	gripList.add(none);
	        	moveList.add(toK10);
	        	gripList.add(none);
	        	moveList.add(toK);
	        	gripList.add(grip);
	        	moveList.add(toK10);
	        	gripList.add(none);
	        	moveList.add(outK10);
	        	gripList.add(release);
	        	moveList.add(fromK10);
	        	gripList.add(none);
	        	moveList.add(fromK);
	        	gripList.add(grip);
	        	moveList.add(fromK10);
	        	gripList.add(none);
	        	moveList.add(outK10);
	        	gripList.add(release);
	        	moveList.add(p1K10);
	        	gripList.add(none);
	        	moveList.add(p1K);
	        	gripList.add(grip);
	        	moveList.add(p1K10);
	        	gripList.add(none);
	        	moveList.add(toK10);
	        	gripList.add(none);
	        	moveList.add(toK);
	        	gripList.add(release);
	        	moveList.add(toK10);
	        	gripList.add(none);
	        	moveList.add(sK);
	        	gripList.add(none);
	        }
	        // promotion for black with capturing:
	        else if(moveLog.get(moveLog.size() - 2).length() == 6 && positionLog.get(positionLog.size() - 1).split(" ")[1].equals("w"))
	        {
	        	moveList.add(sK);
	        	gripList.add(none);
	        	moveList.add(toK10);
	        	gripList.add(none);
	        	moveList.add(toK);
	        	gripList.add(grip);
	        	moveList.add(toK10);
	        	gripList.add(none);
	        	moveList.add(outK10);
	        	gripList.add(release);
	        	moveList.add(fromK10);
	        	gripList.add(none);
	        	moveList.add(fromK);
	        	gripList.add(grip);
	        	moveList.add(fromK10);
	        	gripList.add(none);
	        	moveList.add(outK10);
	        	gripList.add(release);
	        	moveList.add(p2K10);
	        	gripList.add(none);
	        	moveList.add(p2K);
	        	gripList.add(grip);
	        	moveList.add(p2K10);
	        	gripList.add(none);
	        	moveList.add(toK10);
	        	gripList.add(none);
	        	moveList.add(toK);
	        	gripList.add(release);
	        	moveList.add(toK10);
	        	gripList.add(none);
	        	moveList.add(sK);
	        	gripList.add(none);
	        }
        }
		return Result.OK;
	}
}
