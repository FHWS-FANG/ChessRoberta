package application.blocks;
import static com.kuka.roboticsAPI.motionModel.BasicMotions.linRel;
import static com.kuka.roboticsAPI.motionModel.BasicMotions.ptp;
import java.util.List;
import java.lang.Math; 
import javax.inject.Inject;
import com.kuka.appframework.ApplicationBlock;
import com.kuka.grippertoolbox.gripper.zimmer.ZimmerR840;
import com.kuka.roboticsAPI.applicationModel.IApplicationData;
import com.kuka.roboticsAPI.deviceModel.LBR;
import com.kuka.roboticsAPI.geometricModel.Frame;
import com.kuka.roboticsAPI.geometricModel.World;
import com.kuka.task.ITaskLogger;
/**
 * Auto-generated ApplicationBlock class.
 */
public class Move extends ApplicationBlock<Move.Result>
{
	/**
	 * The available result states. Represent the transitions.
	 */
	// To use the sensors of roberta and to create the move command
	@Inject
	private LBR roberta;
	// To use the frames of roberta
	@Inject
	private IApplicationData iApp; 
	
	@Inject
	ITaskLogger logger;
	
	// To grip and release with roberta
	@Inject
	ZimmerR840 ZiGripper;
	
	public enum Result
	{
		OK,
		gameOver
	}
	
	Init vInit = new Init();
	Init2 vInit2 = new Init2();
	
	@Override
	public Result run() throws Exception
	{ 
		
		List<Boolean[]> gripList = vInit2.gripList;
		List<double[]> moveList = vInit2.moveList;
		
		int pause = 1000; 
		double speed = 250;
		 
		// Calculating the correct gripper orientation, so the gripper is parallel to the vector (h1-a1) and looks straight down
		double x1 = iApp.getFrame("/Chessboard/a1").getX();
		double y1 = iApp.getFrame("/Chessboard/a1").getY();
		double x2 = iApp.getFrame("/Chessboard/h8").getX();
		double y2 = iApp.getFrame("/Chessboard/h8").getY();
		double alpha = Math.acos((x2-x1)/Math.sqrt(Math.pow(x2-x1, 2) + Math.pow(y2-y1, 2))) - (Math.PI/4);	
		
		Frame StartPosNew = iApp.getFrame("/StartPos").copyWithRedundancy().setAlphaRad(-0.38+alpha).setBetaRad(0).setGammaRad(-Math.PI);
		roberta.move(ptp(StartPosNew));
		
		if(!vInit.resign)
		{
			// go through the moveList from Init2
			for(int i = 0; i < moveList.size() - 1; i++)
			{
				if(gripList.get(i)[0] == true)
				{
					ZiGripper.gripAsync();
					Thread.sleep(pause);
		            ZiGripper.move(linRel(moveList.get(i+1)[0] - moveList.get(i)[0], moveList.get(i+1)[1] - moveList.get(i)[1], moveList.get(i+1)[2] - moveList.get(i)[2], 0, 0, 0, World.Current.getRootFrame()).setCartVelocity(speed));
				}
				else if (gripList.get(i)[1] == true)
				{
					ZiGripper.gripAsync(ZimmerR840.createAbsoluteMode(21));
					Thread.sleep(pause);
					ZiGripper.move(linRel(moveList.get(i+1)[0] - moveList.get(i)[0], moveList.get(i+1)[1] - moveList.get(i)[1], moveList.get(i+1)[2] - moveList.get(i)[2], 0, 0, 0, World.Current.getRootFrame()).setCartVelocity(speed));
				}
				else 
				{
					ZiGripper.move(linRel(moveList.get(i+1)[0] - moveList.get(i)[0], moveList.get(i+1)[1] - moveList.get(i)[1], moveList.get(i+1)[2] - moveList.get(i)[2], 0, 0, 0, World.Current.getRootFrame()).setCartVelocity(speed));
				}
			}
		}
		 
		if(!vInit.gameOver)
		{
			return Result.OK;
		} 
		else
		{
			return Result.gameOver;
		}
		
	}
}