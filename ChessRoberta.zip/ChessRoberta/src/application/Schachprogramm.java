package application;

import com.kuka.appframework.IAppFwApplication;
import com.kuka.appframework.AppFwApplicationCategory;
import com.kuka.roboticsAPI.applicationModel.tasks.UseRoboticsAPIContext;

/**
 * Auto-generated AppFramework application class.
 */
@AppFwApplicationCategory(model = "Schachprogramm.blm")
@UseRoboticsAPIContext
public class Schachprogramm implements IAppFwApplication
{
	@Override
	public void initialize()
	{
		// TODO Auto-generated method stub
	}

	@Override
	public void dispose()
	{
		// TODO Auto-generated method stub
	}
}
